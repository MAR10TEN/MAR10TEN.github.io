
/**
 * js/animacion.js
 * Contiene toda la lógica para dibujar y animar las figuras en el canvas.
 */

const DURATION = 1500;
const STROKE_COLOR = "#0d6efd";
const FILL_COLOR = "rgba(13, 110, 253, 0.3)";
const LINE_WIDTH = 4;

let currentAnimationId;

function stopAndClearCanvas(ctx) {
    if (currentAnimationId) {
        cancelAnimationFrame(currentAnimationId);
    }
    ctx.clearRect(0, 0, ctx.canvas.width, ctx.canvas.height);
}

function animatePolygon(ctx, sides) {
    stopAndClearCanvas(ctx);
    const c = ctx.canvas;
    const cx = c.width / 2;
    const cy = c.height / 2;
    const radius = Math.min(c.width, c.height) / 2 - 10;
    const points = [];
    const angleStep = (2 * Math.PI) / sides;
    const startAngle = -Math.PI / 2 + (sides % 2 === 0 ? angleStep / 2 : 0);
    for (let i = 0; i < sides; i++) {
        points.push({
            x: cx + radius * Math.cos(startAngle + i * angleStep),
            y: cy + radius * Math.sin(startAngle + i * angleStep),
        });
    }
    animatePolygonFromPoints(ctx, points);
}

function animateCircle(ctx) {
    stopAndClearCanvas(ctx);
    const c = ctx.canvas;
    const cx = c.width / 2;
    const cy = c.height / 2;
    const radius = c.height / 2 - 10;
    const startAngle = -Math.PI / 2;
    let startTime = null;
    function draw(timestamp) {
        if (!startTime) startTime = timestamp;
        const progress = Math.min((timestamp - startTime) / DURATION, 1);
        const endAngle = startAngle + 2 * Math.PI * progress;
        ctx.clearRect(0, 0, c.width, c.height);
        ctx.lineWidth = LINE_WIDTH;
        ctx.strokeStyle = STROKE_COLOR;
        ctx.beginPath();
        ctx.arc(cx, cy, radius, startAngle, endAngle);
        ctx.stroke();
        if (progress >= 1) {
            ctx.beginPath();
            ctx.arc(cx, cy, radius, 0, 2 * Math.PI);
            ctx.fillStyle = FILL_COLOR;
            ctx.fill();
        } else {
            currentAnimationId = requestAnimationFrame(draw);
        }
    }
    currentAnimationId = requestAnimationFrame(draw);
}

function animateTriangleFromSides(ctx, sideA, sideB, sideC) {
    stopAndClearCanvas(ctx);
    const canvas = ctx.canvas;
    const maxSide = Math.max(sideA, sideB, sideC);
    const scale = (canvas.width - 40) / maxSide;
    const a = sideA * scale;
    const b = sideB * scale;
    const c = sideC * scale;

    const p1 = { x: 0, y: 0 };
    const p2 = { x: c, y: 0 };
    const angleA_rad = Math.acos((b * b + c * c - a * a) / (2 * b * c));
    const p3 = {
        x: b * Math.cos(angleA_rad),
        y: b * Math.sin(angleA_rad)
    };

    const points = [p1, p2, p3];

    const minX = Math.min(p1.x, p2.x, p3.x);
    const maxX = Math.max(p1.x, p2.x, p3.x);
    const minY = Math.min(p1.y, p2.y, p3.y);
    const maxY = Math.max(p1.y, p2.y, p3.y);

    const offsetX = (canvas.width - (maxX - minX)) / 2 - minX;
    const offsetY = (canvas.height - (maxY - minY)) / 2 - minY;

    const centeredPoints = points.map(p => ({
        x: p.x + offsetX,
        y: canvas.height - (p.y + offsetY)
    }));

    animatePolygonFromPoints(ctx, centeredPoints);
}

function animateRombo(ctx) {
    stopAndClearCanvas(ctx);
    const c = ctx.canvas;
    const cx = c.width / 2;
    const cy = c.height / 2;
    const d1 = c.width - 40;
    const d2 = c.height - 40;
    const points = [
        { x: cx, y: cy - d2 / 2 },
        { x: cx + d1 / 2, y: cy },
        { x: cx, y: cy + d2 / 2 },
        { x: cx - d1 / 2, y: cy }
    ];
    animatePolygonFromPoints(ctx, points);
}

function animatePolygonFromPoints(ctx, points) {
    const segments = points.map((p1, i) => ({
        p1,
        p2: points[(i + 1) % points.length]
    }));
    let startTime = null;

    function draw(timestamp) {
        if (!startTime) startTime = timestamp;
        const progress = Math.min((timestamp - startTime) / DURATION, 1);
        ctx.clearRect(0, 0, ctx.canvas.width, ctx.canvas.height);
        ctx.lineWidth = LINE_WIDTH;
        ctx.strokeStyle = STROKE_COLOR;

        const totalLength = segments.length;
        const currentLength = progress * totalLength;
        const completedSegments = Math.floor(currentLength);
        const partialSegmentProgress = currentLength - completedSegments;

        for (let i = 0; i < completedSegments; i++) {
            const { p1, p2 } = segments[i];
            ctx.beginPath();
            ctx.moveTo(p1.x, p1.y);
            ctx.lineTo(p2.x, p2.y);
            ctx.stroke();
        }

        if (completedSegments < totalLength) {
            const { p1, p2 } = segments[completedSegments];
            const xi = p1.x + (p2.x - p1.x) * partialSegmentProgress;
            const yi = p1.y + (p2.y - p1.y) * partialSegmentProgress;
            ctx.beginPath();
            ctx.moveTo(p1.x, p1.y);
            ctx.lineTo(xi, yi);
            ctx.stroke();
        }

        if (progress >= 1) {
            ctx.beginPath();
            ctx.moveTo(points[0].x, points[0].y);
            for (let i = 1; i < points.length; i++) {
                ctx.lineTo(points[i].x, points[i].y);
            }
            ctx.closePath();
            ctx.fillStyle = FILL_COLOR;
            ctx.fill();
        } else {
            currentAnimationId = requestAnimationFrame(draw);
        }
    }
    currentAnimationId = requestAnimationFrame(draw);
}

// NUEVA FUNCIÓN: Animar desarrollo plano del dodecaedro
function animarDesarrolloDodecaedro(ctx) {
    stopAndClearCanvas(ctx);

    const LADO = 40; // Longitud del lado del pent��gono
    const CX = ctx.canvas.width / 2;
    const CY = ctx.canvas.height / 2;
    const RAD = Math.PI / 180;
    const ROTACION_INICIAL = -90 * RAD;

    // Dibuja un pent��gono regular dado su centro y ��ngulo
    function dibujarPentagono(x, y, angulo, label = "") {
        const puntos = [];

        for (let i = 0; i < 5; i++) {
            const theta = angulo + i * 72 * RAD;
            const px = x + LADO * Math.cos(theta);
            const py = y + LADO * Math.sin(theta);
            puntos.push({ x: px, y: py });
        }

        animatePolygonFromPoints(ctx, puntos);

        // Etiqueta el centro si se quiere
        if (label) {
            ctx.font = "12px Arial";
            ctx.fillStyle = "black";
            ctx.fillText(label, x - 5, y + 4);
        }

        return puntos;
    }

    function colocarPentagonos() {
        // Dibuja el pent��gono central
        const central = dibujarPentagono(CX, CY, ROTACION_INICIAL, "A");

        // Conecta 5 pent��gonos alrededor del central
        const letrasLaterales = ["B", "C", "D", "E", "F"];
        const letrasExternas = ["G", "H", "I", "J", "K"];

        for (let i = 0; i < 5; i++) {
            const p1 = central[i];
            const p2 = central[(i + 1) % 5];
            const mx = (p1.x + p2.x) / 2;
            const my = (p1.y + p2.y) / 2;

            const anguloLado = Math.atan2(p2.y - p1.y, p2.x - p1.x);
            const normal = anguloLado - 36 * RAD;

            const cx = mx + LADO * Math.cos(normal);
            const cy = my + LADO * Math.sin(normal);

            const exterior = dibujarPentagono(cx, cy, normal + Math.PI, letrasLaterales[i]);

            // Agrega un tercer nivel de pent��gonos en 3 de los lados
            if (i !== 0 && i !== 3) {
                const ep1 = exterior[2];
                const ep2 = exterior[3];
                const emx = (ep1.x + ep2.x) / 2;
                const emy = (ep1.y + ep2.y) / 2;
                const eang = Math.atan2(ep2.y - ep1.y, ep2.x - ep1.x) - 36 * RAD;

                const ecx = emx + LADO * Math.cos(eang);
                const ecy = emy + LADO * Math.sin(eang);

                dibujarPentagono(ecx, ecy, eang + Math.PI, letrasExternas[i]);
            }
        }
    }

    colocarPentagonos();
}


// --- ASIGNACIÓN DE FUNCIONES A `window` ---
window.animarCirculo = animateCircle;
window.animarCuadrado = (ctx) => animatePolygon(ctx, 4);
window.animarTriangulo = (ctx) => animatePolygon(ctx, 3);
window.animateTriangleFromSides = animateTriangleFromSides;
window.animarPentagono = (ctx) => animatePolygon(ctx, 5);
window.animarDodecagono = (ctx) => animatePolygon(ctx, 12);
window.animarRombo = animateRombo;
window.animarDodecaedro = (ctx) => animatePolygon(ctx, 5); // Este sigue siend
window.animarDesarrolloDodecaedro = animarDesarrolloDodecaedro;
window.stopAndClearCanvas = stopAndClearCanvas;
window.animatePolygon = animatePolygon;

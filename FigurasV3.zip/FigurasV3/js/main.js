
/**
 * js/main.js
 * Lógica principal de la calculadora: entrada, cálculo, visualización y animación.
 */

document.addEventListener('DOMContentLoaded', () => {
    const figuraSelect = document.getElementById('figura');
    const form = document.getElementById('calculadora-form');

    if (figuraSelect) {
        figuraSelect.addEventListener('change', seleccionarFigura);
        seleccionarFigura();
    }

    if (form) {
        form.addEventListener('submit', calcular);
    }
});

function seleccionarFigura() {
    const figura = document.getElementById('figura').value;
    const camposDiv = document.getElementById('campos-calculo');
    const canvas = document.getElementById('animationCanvas');
    const ctx = canvas.getContext('2d');

    camposDiv.innerHTML = '';
    document.getElementById('resultado').style.display = 'none';

    let camposHTML = '';

    switch (figura) {
        case 'circulo':
            camposHTML = inputField('radio', 'Radio');
            if (window.animarCirculo) window.animarCirculo(ctx);
            break;
        case 'cuadrado':
        case 'pentagono':
        case 'dodecagono':
        case 'hexagono':
            camposHTML = inputField('lado', 'Lado');
            if (window[`animar${capitalize(figura)}`]) {
                window[`animar${capitalize(figura)}`](ctx);
            }
            break;
        case 'triangulo':
            camposHTML = inputField('ladoA', 'Lado A') + inputField('ladoB', 'Lado B') + inputField('ladoC', 'Lado C');
            if (window.animarTriangulo) window.animarTriangulo(ctx);
            break;
        case 'rombo':
            camposHTML = inputField('diagonal-mayor', 'Diagonal Mayor') + inputField('diagonal-menor', 'Diagonal Menor');
            if (window.animarRombo) window.animarRombo(ctx);
            break;
        case 'dodecaedro':
        case 'octaedro':
            camposHTML = inputField('arista', 'Arista');
            if (window[`animar${capitalize(figura)}`]) {
                window[`animar${capitalize(figura)}`](ctx);
            }
            break;
        default:
            if (window.stopAndClearCanvas) window.stopAndClearCanvas(ctx);
    }

    camposDiv.innerHTML = camposHTML;
}

function inputField(id, label) {
    return `
        <div class="mb-3">
            <label for="${id}" class="form-label">${label}:</label>
            <input type="number" id="${id}" class="form-control" required min="0" step="any" placeholder="Ej: 10">
        </div>`;
}

function capitalize(str) {
    return str.charAt(0).toUpperCase() + str.slice(1);
}

async function calcular(event) {
    event.preventDefault();

    const figuraSelect = document.getElementById('figura');
    const figuraValor = figuraSelect.value;
    const figuraNombre = figuraSelect.options[figuraSelect.selectedIndex].text;
    const resultadoDiv = document.getElementById('resultado');

    let calculoTexto = `Resultado para: ${figuraNombre}\n`;
    let calculoExitoso = false;

    try {
        switch (figuraValor) {
            case 'circulo': {
                const radio = leerValor('radio');
                const area = Math.PI * radio ** 2;
                const perimetro = 2 * Math.PI * radio;
                calculoTexto += `Área: ${area.toFixed(3)}\nPerímetro: ${perimetro.toFixed(3)}`;
                calculoExitoso = true;
                break;
            }
            case 'cuadrado': {
                const lado = leerValor('lado');
                const area = lado ** 2;
                const perimetro = 4 * lado;
                calculoTexto += `Área: ${area.toFixed(3)}\nPerímetro: ${perimetro.toFixed(3)}`;
                calculoExitoso = true;
                break;
            }
            case 'triangulo': {
                const a = leerValor('ladoA');
                const b = leerValor('ladoB');
                const c = leerValor('ladoC');
                if (a + b <= c || a + c <= b || b + c <= a)
                    throw new Error("Los lados no forman un triángulo válido.");

                const s = (a + b + c) / 2;
                const area = Math.sqrt(s * (s - a) * (s - b) * (s - c));
                const perimetro = a + b + c;

                let tipo = "Escaleno";
                if (a === b && b === c) tipo = "Equilátero";
                else if (a === b || b === c || a === c) tipo = "Isósceles";

                const radA = Math.acos((b ** 2 + c ** 2 - a ** 2) / (2 * b * c));
                const radB = Math.acos((a ** 2 + c ** 2 - b ** 2) / (2 * a * c));
                const radC = Math.PI - radA - radB;

                const deg = r => (r * 180 / Math.PI).toFixed(2);

                calculoTexto += `Tipo: ${tipo}\nÁrea: ${area.toFixed(3)}\nPerímetro: ${perimetro.toFixed(3)}\nÁngulos: A=${deg(radA)}°, B=${deg(radB)}°, C=${deg(radC)}°`;

                if (window.animateTriangleFromSides) {
                    const ctx = document.getElementById('animationCanvas').getContext('2d');
                    window.animateTriangleFromSides(ctx, a, b, c);
                }

                calculoExitoso = true;
                break;
            }
            case 'pentagono': {
                const lado = leerValor('lado');
                const perimetro = 5 * lado;
                const apotema = lado / (2 * Math.tan(Math.PI / 5));
                const area = (perimetro * apotema) / 2;
                calculoTexto += `Área: ${area.toFixed(3)}\nPerímetro: ${perimetro.toFixed(3)}`;
                calculoExitoso = true;
                break;
            }
            case 'rombo': {
                const dMayor = leerValor('diagonal-mayor');
                const dMenor = leerValor('diagonal-menor');
                const area = (dMayor * dMenor) / 2;
                const lado = Math.sqrt((dMayor / 2) ** 2 + (dMenor / 2) ** 2);
                const perimetro = 4 * lado;
                calculoTexto += `Área: ${area.toFixed(3)}\nPerímetro: ${perimetro.toFixed(3)}`;
                calculoExitoso = true;
                break;
            }
            case 'dodecagono': {
                const lado = leerValor('lado');
                const perimetro = 12 * lado;
                const area = 3 * (2 + Math.sqrt(3)) * lado ** 2;
                calculoTexto += `Área: ${area.toFixed(3)}\nPerímetro: ${perimetro.toFixed(3)}`;
                calculoExitoso = true;
                break;
            }
            case 'dodecaedro': {
                const arista = leerValor('arista');
                const area = 3 * Math.sqrt(25 + 10 * Math.sqrt(5)) * arista ** 2;
                const volumen = (15 + 7 * Math.sqrt(5)) / 4 * arista ** 3;
                calculoTexto += `Área de Superficie: ${area.toFixed(3)}\nVolumen: ${volumen.toFixed(3)}`;
                calculoExitoso = true;
                break;
            }
            case 'hexagono': {
                const lado = leerValor('lado');
                const perimetro = 6 * lado;
                const area = (3 * Math.sqrt(3) * lado ** 2) / 2;
                calculoTexto += `Área: ${area.toFixed(3)}\nPerímetro: ${perimetro.toFixed(3)}`;
                calculoExitoso = true;
                break;
            }
            case 'octaedro': {
                const arista = leerValor('arista');
                const area = 2 * Math.sqrt(3) * arista ** 2;
                const volumen = (Math.sqrt(2) / 3) * arista ** 3;
                calculoTexto += `Área de Superficie: ${area.toFixed(3)}\nVolumen: ${volumen.toFixed(3)}`;
                calculoExitoso = true;
                break;
            }
            case 'desarrollo_dodecaedro':
                camposHTML = '<p>Desarrollo plano del dodecaedro.</p>';
                if (window.animarDesarrolloDodecaedro) {
                    window.animarDesarrolloDodecaedro(ctx);
                }
                break;

            default:
                calculoTexto = "Por favor, selecciona una figura y completa los campos.";
        }
    } catch (error) {
        calculoTexto = `Error: ${error.message}`;
        calculoExitoso = false;
    }

    mostrarResultado(resultadoDiv, calculoTexto, calculoExitoso);

    if (calculoExitoso) {
        await guardarEnHistorial(figuraNombre);
    }
}

function leerValor(id) {
    const valor = parseFloat(document.getElementById(id).value);
    if (isNaN(valor) || valor <= 0) {
        throw new Error(`El valor de "${id}" debe ser un número positivo.`);
    }
    return valor;
}

function mostrarResultado(div, texto, exito) {
    div.innerText = texto;
    div.className = exito ? 'alert alert-success mt-4' : 'alert alert-danger mt-4';
    div.style.display = 'block';
}

async function guardarEnHistorial(figuraNombre) {
    try {
        const response = await fetch('guardar_calculo.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ figura: figuraNombre })
        });
        const result = await response.json();
        if (result.success) {
            console.log('Historial guardado en la base de datos.');
            actualizarHistorialEnVivo(figuraNombre);
        } else {
            console.error('Error del servidor al guardar:', result.message);
        }
    } catch (error) {
        console.error('Error en la solicitud fetch:', error);
    }
}

function actualizarHistorialEnVivo(figuraNombre) {
    const listaHistorial = document.getElementById('historial-lista');
    if (!listaHistorial || listaHistorial.innerText.includes('no disponible para invitados')) return;

    const itemVacio = listaHistorial.querySelector('.placeholder-glow, .text-danger');
    if (itemVacio && listaHistorial.children.length === 1) {
        listaHistorial.innerHTML = '';
    }

    const nuevoItem = document.createElement('li');
    nuevoItem.className = 'list-group-item';

    const fechaActual = new Date();
    const fechaFormateada = fechaActual.toLocaleString('es-ES', {
        day: '2-digit', month: '2-digit', year: 'numeric',
        hour: '2-digit', minute: '2-digit'
    });

    nuevoItem.innerHTML = `${figuraNombre} <span class="text-muted small">(${fechaFormateada})</span>`;
    listaHistorial.prepend(nuevoItem);

    while (listaHistorial.children.length > 10) {
        listaHistorial.lastChild.remove();
    }
}
